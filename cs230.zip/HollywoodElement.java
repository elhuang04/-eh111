
/**
 * The parent class of vertices in hollywood graphs (actors and movies)
 *
 * @author Katie Emerson
 * @author Elizabeth Huang
 * @author Julia Niemann
 * @version 12.11.2023
 */
public abstract class HollywoodElement
{
    protected String name; //the name of the actor/title of movie (identifying feature of the element)
    protected String type; //the type of HollywoodElement (movie or actor)
    
    /**
     * Constructor for objects of class HollywoodElement
     */
    public HollywoodElement(String name, String type)
    {
        this.name = name;
        this.type = type;
    }
    
    /**
     * A predicate method to see if two HollywoodElements are equal.
     * Checks first if the input Object is a HollywoodElement for type safety,
     * though the parameter is never not a HollywoodElement in our project.
     * 
     * @Override the .equals method in class Object.
     * @return true if they are equal, false otherwise.
     */
    public boolean equals(Object e) {
        return (e instanceof HollywoodElement) && (this.type.equals(((HollywoodElement)e).type) && this.name.equals(((HollywoodElement) e).name));
    }
    
    /**
     * Returns the name of the HollywoodElement (actor's name or film title).
     * 
     * @return name  the name/title of the actor/movie
     */
    public String getName() {
        return name;
    }
    
    /**
     * Returns the type of this element (actor or movie).
     * 
     * @return type  the type of the element, movie or actor
     */
    public String getType() {
        return type;
    }
}
