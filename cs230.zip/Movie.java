import java.util.ArrayList;

/**
 * A class to describe a movie. Extends HollywoodElement
 *
 * @author Katie Emerson
 * @author Elizabeth Huang
 * @author Julia Niemann
 * @version 12.11.2023
 */
public class Movie extends HollywoodElement
{
    String leadingActorGender; //stores the gender of the highest paid role for use in our Bechdel Test.
    ArrayList<Actor> cast; //stores the actor names and genders of characters they play in the movie
    
    /**
     * Provides a String description of the class
     * 
     * @return the name of the movie
     */
    public String toString() {
        return super.name;
    }
    
    /**
     * Returns the gender of the highest paid cast member.
     * 
     * @return leadingActorGender  the gender of the highest paid cast member.
     */
    public String getLeadGender() {
        return leadingActorGender;
    }
    
    /**
     * Adds an actor to the cast of the movie.
     * 
     * @param a  the actor to be added.
     */
    public void add(Actor a) {
        cast.add(a);
    }

    /**
     * Constructor for objects of class Movie
     * 
     * @param title  the title of the movie
     * @param gender  the String gender of the highest paid role
     */
    public Movie(String title, String gender)
    {
        super(title, "movie");
        leadingActorGender = gender;
        cast = new ArrayList<Actor>();
    }
    
    /**
     * Returns the cast of the movie
     * 
     * @return the cast of the film, an ArrayList of Actors.
     */
    public ArrayList<Actor> getCast() {
        return cast;
    }
    
    /**
     * The main method, for testing.
     */
    public static void main(String[] args) {
        System.out.println("TESTING MOVIE CLASS");
        Movie m = new Movie("Interstellar", "Male");
        m.add(new Actor("Timothee Chalamet", "Male"));
        m.add(new Actor("Matthew McConaughhey", "Male"));
        m.add(new Actor("Anne Hathaway", "Female"));
        m.add(new Actor("Jessica Chastain", "Female"));
        System.out.println(m + " Gender of leading actor: "+m.getLeadGender());
        System.out.println("Cast:\n"+m.getCast());
    }
}
