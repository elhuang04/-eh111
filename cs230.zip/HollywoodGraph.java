import java.util.*;
import java.io.*;
import javafoundations.*;
/**
 * A class to represent an undirected graph of actors and movies.
 *
 * @author Katie Emerson
 * @author Elizabeth Huang
 * @author Julia Niemann
 * @version 12.11.2023
 */
public class HollywoodGraph
{
    private AdjListsGraph<HollywoodElement> graph; //the graph
    private int bechdelPassValue = 50; //% of roles needed to pass the Bechdel test

    /**
     * Constructor for objects of class HollywoodGraph
     * 
     * @param fileName  the name of the file being read from
     */
    public HollywoodGraph(String fileName)
    {
        try {
            graph = new AdjListsGraph<HollywoodElement>();
            Scanner lineScan = new Scanner(new File(fileName));
            lineScan.nextLine();
            Movie previous = new Movie("Interstellar", "Male"); //random movie that came out in 2014 so will never be in the data file, to initialize the variable with
            while (lineScan.hasNext()) {
                String line = lineScan.nextLine();
                String[] tokens = line.split("\",\"");
                tokens[0] = tokens[0].substring(1);//gets rid of leading "
                tokens[5] = tokens[5].substring(0, tokens[5].length()-1);//gets rid of final "
                Actor actor = new Actor(tokens[1], tokens[5]);
                Movie movie = new Movie(tokens[0], tokens[5]);
                if (!movie.equals(previous)) {
                    previous = movie;
                    movie.add(actor);
                } else {
                    previous.add(actor);
                }
                graph.addVertex(movie);
                graph.addVertex(actor);
                graph.addEdge(actor, movie);
            } 
        } catch (FileNotFoundException e) {
            System.out.println("File not found");
        }
    }

    /**
     * Returns a list of the movies this actor was in.
     * 
     * @param Actor a  the actor whose filmography was being searched for.
     * @return LinkedList<HollywoodElement> representing the movies the actor was in.
     */

    public ArrayList<Movie> filmography(Actor a) {
        ArrayList<Movie> filmography = new ArrayList<Movie>();
        for (int i=0; i<graph.getNumVertices(); i++) {
            if (graph.isEdge(graph.getVertex(i), a)) {
                filmography.add((Movie)(graph.getVertex(i))); //we know it will always be a movie because the graph is bipartite
            }
        }
        return filmography;
    }

    /**
     * Returns a list of the actors in the movie.
     * 
     * @param Movie m  the movie whose cast is being searched for
     * @return LinkedList<HollywoodElement> representing the cast of the movie
     */

    public ArrayList<Actor> cast(Movie m) {
        ArrayList<Actor> cast = new ArrayList<Actor>();
        for (int i=0; i<graph.getNumVertices(); i++) {
            if (graph.isEdge(graph.getVertex(i), m)) {
                cast.add((Actor)(graph.getVertex(i))); //we know it will always be an actor because the graph is bipartite
            }
        }
        return cast;
    }

    /**
     * Returns a String description of the graph
     * 
     * @return a String description of the Graph
     */
    public String toString() {
        return graph.toString();
    }

    /**
     * Saves the hollywoodGraph to a tgf file
     * 
     * @param fName  the file to be saved to
     */
    public void saveTGF(String fName) {
        graph.saveTGF(fName);
    }

    /**
     * Returns the count of movies between to actors.
     * 
     * @param a1  the first actor
     * @param a2  the second actor
     * @return the count of movies between actors a1 and a2 (0 if they were in the same
     * movie, and then +n for every n more movies between them)
     */
    public int BFS(Actor a1, Actor a2) {
        int count = 0;
        ArrayList<HollywoodElement> path = graph.BFS(a1, a2);
        for (int i=0; i<path.size(); i++) {
            //System.out.println(path.get(i)); //for testing
            if (path.get(i) instanceof Movie) {
                count++;
            }
        }
        return count-1;
    }

    /**
     * Runs our Bechdel Test on the given movie
     * A movie will pass if the leading character (billing #1) is female and
     * the cast is 50% female or unknown gender roles.
     * 
     * @param m  the movie to be tested
     * @return true if the movie passes, false otherwise.
     */
    public boolean bechdelTest(Movie m) {
        ArrayList<Actor> cast = m.getCast();
        int countFemale = 0;
        int femaleMax = -1;
        int maleMax = -1;
        for (int i=0; i<cast.size(); i++) {
            Actor a = (Actor) cast.get(i);
            if (a.getGender().equals("Female") || a.getGender().equals("Unknown")) {
                countFemale++;
            }
        }
        double percent = ((double)countFemale)/cast.size();
        percent*=100;
        return bechdelPassValue<=percent && m.getLeadGender().equalsIgnoreCase("female");
    }

    /**
     * Runs the bechdel test across the whole graph
     * 
     * @return ArrayList<Movie> of the movies that passed the test.
     */
    public ArrayList<Movie> runBechdel() {
        ArrayList<Movie> movies = new ArrayList<Movie>();
        for (int i=0; i<graph.getNumVertices(); i++) {
            if (graph.getVertex(i) instanceof Movie) {
                if (bechdelTest((Movie)graph.getVertex(i))) {
                    movies.add((Movie)graph.getVertex(i));
                }
            }
        }
        return movies;
    }

    /**
     * The main method, for testing.
     */
    public static void main(String[] args) {
        System.out.println("TESTING HOLLYWOOD GRAPH ON SMALL DATA SET");
        HollywoodGraph h = new HollywoodGraph("small_castGender.txt");
        System.out.println(h);
        System.out.println("Tyler Perry's movies "+h.filmography(new Actor("Tyler Perry", "Male")));
        System.out.println("Cast of Alpha "+h.cast(new Movie("Alpha", "Male")));
        int iter = h.BFS(new Actor("Takis", "Female"), new Actor("Stella", "Male"));
        System.out.println("Path length from Takis to Stella: "+(iter));
        System.out.println("Bechdel test results\n"+h.runBechdel());
        h.saveTGF("small_CastGenderGraph.tgf");

        System.out.println("TESTING HOLLYWOOD GRAPH ON FULL DATA SET");
        HollywoodGraph h2 = new HollywoodGraph("nextBechdel_castGender.txt");
        System.out.println("Cast of the Jungle Book:\n"+h2.cast(new Movie("The Jungle Book", "Male")));
        System.out.println("Filmography of Jennifer Lawrence:\n"+h2.filmography(new Actor("Jennifer Lawrence", "Female")));
        System.out.println("Path length between Megan Fox and Tyler Perry: "+h2.BFS(new Actor("Megan Fox", "Female"), new Actor("Tyler Perry", "Male")));
        System.out.println("Path length between Nick Arapoglou and Tyler Perry: "+h2.BFS(new Actor("Nick Arapoglou", "Male"), new Actor("Tyler Perry", "Male")));
        System.out.println("Bechdel test results\n"+h2.runBechdel());

    }
}