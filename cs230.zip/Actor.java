import java.util.ArrayList;

/**
 * A class to represent an actor. Extends HollywoodElement.
 *
 * @author Katie Emerson
 * @author Elizabeth Huang
 * @author Julia Niemann
 * @version 12.11.2023
 */
public class Actor extends HollywoodElement
{
    private String gender;
    
    /**
     * Constructor for objects of class Actor
     * 
     * @param name  the name of the actor
     * @param gender  the gender of the actor
     * 
     * KNOWN BUG: gender is currently read in as the gender of the first role they appear in.
     * This usually aligns with their gender; not always, but it is still an attribute
     * of the actor class in case we want to read a file where the gender corresponds
     * to the actor and not to the role, which is how we had originally interpreted
     * the data file.
     */
    public Actor(String name, String gender)
    {
        super(name, "actor");
        this.gender = gender;
    }
    
    /**
     * The toString() method, to describe the class
     * 
     * @return a String description of the Actor
     */
    public String toString() {
        return super.name;
    }

    /**
     * Gets the gender of the actor
     * 
     * @return the gender of the actor
     */
    public String getGender() {
        return gender;
    }
    
    /**
     * The main method, for testing
     */
    public static void main(String[] args) {
        System.out.println("TESTING ACTOR CLASS");
        Actor a = new Actor("Takis", "Female");
        System.out.println(a+" Gender: "+a.getGender());
        
        Actor a1 = new Actor("Stella", "Male");
        System.out.println(a1+" Gender: "+a1.getGender());
        
        Actor a2 = new Actor("Cassi Davis", "Unknown");
        System.out.println(a2+" Gender: "+a2.getGender());
    }
}